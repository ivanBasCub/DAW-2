<?php
function fin_html(){
        echo "</main>";
        echo "<footer>";
        echo"</footer>";
    echo "</html>";
}
