<?php

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\ORM\Mapping as ORM;

/**
 * Equipo
 *
 * @ORM\Table(name="tipoivanbascones")
 * @ORM\Entity
 */
class TipoivanbasconesBidireccional
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="nombre", type="string", length=100, nullable=false)
     */
    private $tipo;

    /**
     * @var string
     *
     * @ORM\Column(name="socios", type="string", length=100, nullable=false)
     */
    private $descripcion;

    /**
     * Un tipo tiene muchos articulo
     * @ORM\OneToMany(targetEntity="ArticuloivanbasconesBidireccional", mappedBy="Tipoivanbascones")
     */
    private $articulos;

    public function __construct()
    {
        $this -> articulos = new ArrayCollection();
    }

    /**
     * Get the value of id
     *
     * @return  int
     */ 
    public function getId()
    {
        return $this->id;
    }

    /**
     * Get the value of tipo
     *
     * @return  string
     */ 
    public function getTipo()
    {
        return $this->tipo;
    }

    /**
     * Set the value of tipo
     *
     * @param  string  $tipo
     *
     * @return  self
     */ 
    public function setTipo(string $tipo)
    {
        $this->tipo = $tipo;

        return $this;
    }

    /**
     * Get the value of descripcion
     *
     * @return  string
     */ 
    public function getDescripcion()
    {
        return $this->descripcion;
    }

    /**
     * Set the value of descripcion
     *
     * @param  string  $descripcion
     *
     * @return  self
     */ 
    public function setDescripcion(string $descripcion)
    {
        $this->descripcion = $descripcion;

        return $this;
    }

    /**
     * Get un tipo tiene muchos articulo
     */ 
    public function getArticulos()
    {
        return $this->articulos;
    }

    /**
     * Set un tipo tiene muchos articulo
     *
     * @return  self
     */ 
    public function setArticulos($articulos)
    {
        $this->articulos = $articulos;

        return $this;
    }
}
