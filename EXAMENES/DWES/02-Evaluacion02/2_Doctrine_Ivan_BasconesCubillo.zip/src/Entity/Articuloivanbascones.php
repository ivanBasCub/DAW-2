<?php



use Doctrine\ORM\Mapping as ORM;

/**
 * Equipo
 *
 * @ORM\Table(name="articuloivanbascones")
 * @ORM\Entity
 */
class Articuloivanbascones
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="titulo", type="string", length=100, nullable=false)
     */
    private $titulo;

    /**
     * @var date
     *
     * @ORM\Column(name="fecha", type="date", nullable=false)
     */
    private $fecha;

    /**
     * @var string
     *
     * @ORM\Column(name="text", type="longtext", nullable=true)
     */
    private $text;

    /**
     * @var \Tipoivanbascones
     *
     * @ORM\ManyToOne(targetEntity="Tipoivanbascones")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="tipoivanbascones", referencedColumnName="id")
     * })
     */
    private $tipo;

    /**
     * Get the value of id
     *
     * @return  int
     */ 
    public function getId()
    {
        return $this->id;
    }

    /**
     * Get the value of titulo
     *
     * @return  string
     */ 
    public function getTitulo()
    {
        return $this->titulo;
    }

    /**
     * Set the value of titulo
     *
     * @param  string  $titulo
     *
     * @return  self
     */ 
    public function setTitulo(string $titulo)
    {
        $this->titulo = $titulo;

        return $this;
    }

    /**
     * Get the value of fecha
     *
     * @return  date
     */ 
    public function getFecha()
    {
        return $this->fecha;
    }

    /**
     * Set the value of fecha
     *
     * @param  date  $fecha
     *
     * @return  self
     */ 
    public function setFecha(date $fecha)
    {
        $this->fecha = $fecha;

        return $this;
    }

    /**
     * Get the value of text
     *
     * @return  string
     */ 
    public function getText()
    {
        return $this->text;
    }

    /**
     * Set the value of text
     *
     * @param  string  $text
     *
     * @return  self
     */ 
    public function setText(string $text)
    {
        $this->text = $text;

        return $this;
    }

    /**
     * Get the value of tipo
     *
     * @return  \Tipoivanbascones
     */ 
    public function getTipo()
    {
        return $this->tipo;
    }

    /**
     * Set the value of tipo
     *
     * @param  \Tipoivanbascones  $tipo
     *
     * @return  self
     */ 
    public function setTipo(\Tipoivanbascones $tipo)
    {
        $this->tipo = $tipo;

        return $this;
    }
}
