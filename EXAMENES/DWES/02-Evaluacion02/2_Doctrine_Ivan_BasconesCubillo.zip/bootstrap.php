<?php
// bootstrap.php
// Include Composer Autoload (relative to project root)
require_once "./vendor/autoload.php";
use Doctrine\ORM\Tools\Setup;
use Doctrine\ORM\EntityManager;
$paths = array("./src");
$isDevMode = true;

// Configuración de la BBDD
$dbParams = array(
    'driver' => 'pdo_mysql',
    'user' => 'root',
    'password' => '',
    'dbname' => 'darticulos_ivanbascones',
    'host' => 'localhost',
);
/*
Utilizara los siguientes parametros:
    - Ruta a las entidades
    - Si estamos en modo desarrollo si queremos hacer depuración
    - Dirección Temporal
    - Sistema de cache
    - Si se usa un tipo de lector de anotaciones simples
*/
$config = Setup::createAnnotationMetadataConfiguration($paths, $isDevMode, null, null, false);
$entityManager = EntityManager::create($dbParams,$config);

?>