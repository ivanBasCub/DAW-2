<?php
    // Ivan Bascones Cubillo
    require_once "controlador_libro.php";
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Vaciar carrito</title>
</head>

<body>
    <h1>Vaciar carrito</h1>
    <?php
    //Vacía el carrito mostrando un mensaje
    unset($_SESSION['carrito']);

    echo "<h2>Se ha borrado el carrito correctamente</h2>";
    //Da la posiblidad de volver al listado de libros a comprar
    ?>
    <p><a href="libros.php">Volver al listado</a></p>
</body>

</html>