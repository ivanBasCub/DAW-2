<?php
// Ivan Bascones Cubillo
require_once "controlador_libro.php";
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Detalle del pago de los libros:</title>
</head>

<body>
    <h1>Detalle del pago de los libros</h1>
    <?php
    if(isset($_SESSION['error'])){
        echo "<h3>". $_SESSION['error'] ."</h3>";
    }
    //Muestra el detalle del pago
    $total = 0;
    if (empty($_SESSION["carrito"])) {
        echo "<p> El carrito esta vacio</p>";
    } else {
        echo "<h1>Carrito de productos:</h1>";
        echo "<ul>";
        foreach ($_SESSION["carrito"] as $lb) {
            $libro = unserialize($lb);
            echo "<li>";
                echo $libro->getCantidad() . " - " . $libro->getTitulo() . " - " . $libro->getPrecio() * $libro->getCantidad() . " &euro;";
            echo "</li>";
            $total += $libro->getPrecio() * $libro->getCantidad();
        }
        echo "</ul>";
    }
    echo "<p>Precio Total: $total &euro;</p>"
    //Da la posibilidad de:
    //- Realizar el pago
    //- Volver al carrito
    //- Volver al listado de los libros

    ?>
    <form action="controlador_libro.php" method="post">
        <input type="submit" name="compra" value="Realizar la compra">
    </form>
    <br>
    <a href="carrito_libro.php">Volver al carrito</a>
    <a href="libros.php">Volver a la lista</a>
</body>

</html>