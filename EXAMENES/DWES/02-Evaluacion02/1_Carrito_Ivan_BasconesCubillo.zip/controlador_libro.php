<?php
// Ivan Bascones Cubillo
//Genera una Lista de libros (simulando una base de datos)
//Contiene la lógiga de negocio del manejo del carrito

session_start();

// Incluimos la clase libro
require_once "Libro.php";

// Generamos una lista de libros 
$libros = [
    new Libro(1, "Ivan Bascones", 20,12),
    new Libro(2, "Divergente", 30,15),
    new Libro(3, "Felicidad", 10,5)
];

// Crear el carrito si no existe
if (!isset($_SESSION["carrito"])) {
    $_SESSION['carrito'] = [];
}

// Agregamos un libro al carrito
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['agregar'])) {
    $indice = $_POST['indice'];
    $id = $libros[$indice]->getId();

    if (empty($_SESSION['carrito'])) {
        $libro = $libros[$indice];
        $libro -> setCantidad(1);
        $_SESSION['carrito'][] = serialize($libro);
    } else {
        $aux = 0;
        // Comprobamos todos los objetos que hay dentro del array
        foreach ($_SESSION['carrito'] as $lb) {
            $libro = unserialize($lb);
            // Si en el caso de que exista le sumamos uno y salimos del bucle
            if ($libro->getId() == $id) {
                $cantidad = $libro->getCantidad();
                $libro->setCantidad($cantidad + 1);

                $lb = serialize($libro);
                $_SESSION['carrito'][$aux] = $lb;
                header('Location: libros.php');
                exit;
            }
            $aux++;
        }
        // En el caso de q no exista en el array lo añadimos
        $libro = $libros[$indice];
        $libro -> setCantidad(1);
        $_SESSION['carrito'][] = serialize($libro);
    }

    header('Location: libros.php');
    exit;
}

// Comprobamos si queremos eliminar producto del array
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['quitar'])) {
    $id = $_POST["id"];
    $aux = 0;
    foreach ($_SESSION['carrito'] as $lb) {
        $libro = unserialize($lb);
        if ($libro->getId() == $id) {
            unset($_SESSION['carrito'][$aux]);
            // Reoganizacion de los index del array
            $_SESSION['carrito'] = array_values($_SESSION['carrito']);
            header("Location: carrito_libro.php");
        }
        $aux++;
    }
}

// Comprobamos si la compra esta bien realizada
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['compra'])) {
    $check = 0;
    foreach($_SESSION['carrito'] as $lb){
        $libro = unserialize($lb);
        foreach($libros as $bbddLibro){
            if($libro -> getId() == $bbddLibro -> getId() && $libro -> getCantidad() <= $bbddLibro -> getCantidad()){
                $check++;
            }
        }
    }

    if($check == count($_SESSION['carrito'])){
        header("Location: pago_realizado.php");
    }else{
        $_SESSION['error'] = "No hay suficientes existencias";
        header("Location: detalle_pago_libro.php");
    }
}