<?php
// Ivan Bascones Cubillo
   // Metemos el controlador para obtener los productos 
   require_once "controlador_libro.php";
   require_once "Libro.php";
?>
<!DOCTYPE html>
<html lang="es">

<head>
   <meta charset="UTF-8">
   <title>Carrito de libros</title>
</head>

<body>
   <h1>Carrito de Libros</h1>
   <?php
      //Muestra el carrito con los libros añadidos si no está vacío
      //Da posibilidad de:
      //- Ir al detalle del pago
      //- Vaciar el carrito
      //- Volver al listado de los libros para seguir comprando en todo caso
      if (empty($_SESSION["carrito"])){
         echo "<p> El carrito esta vacio</p>";
      }else{
         echo "<h1>Carrito de productos:</h1>";
         echo "<ul>";
            foreach($_SESSION["carrito"] as $lb){
               $libro = unserialize($lb);
               if($libro -> getCantidad() != 0){
                  echo "<li>"; 
                  echo $libro -> getCantidad() ." - ". $libro -> getTitulo() ." - ". $libro -> getPrecio() * $libro -> getCantidad() . " &euro;";
                  echo "<form action='controlador_libro.php' method='post'>";
                  echo "<input type='submit' name='quitar' value='Borrar'>";
                  echo "<input type='hidden' name='id' value='". $libro -> getId() ."'>";
                  echo "</form>";
                  echo "</li>";
               }
            }

         echo "</ul>";
      }
   ?>
   <a href="detalle_pago_libro.php">Finalizar Compra</a>
   <a href="vaciar_carrito.php">Vaciar el carrito</a>
   <a href="libros.php">Volver al menu principal</a>
</body>

</html>