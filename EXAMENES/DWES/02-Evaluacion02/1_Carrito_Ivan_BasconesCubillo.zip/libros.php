<?php
// Ivan Bascones Cubillo
    // Metemos el controlador para obtener los productos 
    require_once "controlador_libro.php";

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Libros</title>
</head>
<body>
    <h1>Libros disponibles para comprar</h1>
    <!--Listado de los libros disponibles para añdir al carrito -->
    <ul>
        <?php foreach($libros as $indice => $libro){ ?>
            <li>
                <?= $libro -> getTitulo() ?> - Cantidad: <?= $libro -> getCantidad() ?> - Precio <?= $libro -> getPrecio() ?> &euro; 
                <form action="controlador_libro.php" method="post">
                    <input type="hidden" name="indice" value="<?= $indice ?>">
                    <input type="submit" name="agregar" value="Agregar al carrito">
                </form>
            </li>
        <?php }?>
    </ul>
    <!--Posibilidad de ver el carrito -->
    <p><a href="carrito_libro.php">Ver el carrito</a></p>

</body>
</html>
