<?php
    // Ivan Bascones Cubillo
    require_once "controlador_libro.php";
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Pago de libros realizado</title>
</head>

<body>
    <h1>Pago de libros realizado</h1>
    <?php
    //Simula el pago de los libros mostrando un mensaje
    echo "<h2>Muchas gracias por comprar</h2>";
    unset($_SESSION['carrito']);
    if(isset($_SESSION['error'])){
        unset($_SESSION['error']);
    }
    //Da la posiblidad de volver al listado de libros a comprar
    ?>
    <a href="libros.php">Volver al menu principal</a>
</body>

</html>