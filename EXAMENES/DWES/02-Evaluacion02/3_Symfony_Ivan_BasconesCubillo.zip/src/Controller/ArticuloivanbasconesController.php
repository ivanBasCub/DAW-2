<?php

namespace App\Controller;

use App\Entity\Articuloivanbascones;
use App\Form\ArticuloivanbasconesType;
use App\Repository\ArticuloivanbasconesRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

#[Route('/articuloivanbascones')]
final class ArticuloivanbasconesController extends AbstractController
{
    #[Route(name: 'app_articuloivanbascones_index', methods: ['GET'])]
    public function index(ArticuloivanbasconesRepository $articuloivanbasconesRepository): Response
    {
        return $this->render('articuloivanbascones/index.html.twig', [
            'articuloivanbascones' => $articuloivanbasconesRepository->findAll(),
        ]);
    }

    #[Route('/new', name: 'app_articuloivanbascones_new', methods: ['GET', 'POST'])]
    public function new(Request $request, EntityManagerInterface $entityManager): Response
    {
        $articuloivanbascone = new Articuloivanbascones();
        $form = $this->createForm(ArticuloivanbasconesType::class, $articuloivanbascone);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $entityManager->persist($articuloivanbascone);
            $entityManager->flush();

            return $this->redirectToRoute('app_articuloivanbascones_index', [], Response::HTTP_SEE_OTHER);
        }

        return $this->render('articuloivanbascones/new.html.twig', [
            'articuloivanbascone' => $articuloivanbascone,
            'form' => $form,
        ]);
    }

    #[Route('/{id}', name: 'app_articuloivanbascones_show', methods: ['GET'])]
    public function show(Articuloivanbascones $articuloivanbascone): Response
    {
        return $this->render('articuloivanbascones/show.html.twig', [
            'articuloivanbascone' => $articuloivanbascone,
        ]);
    }

    #[Route('/{id}/edit', name: 'app_articuloivanbascones_edit', methods: ['GET', 'POST'])]
    public function edit(Request $request, Articuloivanbascones $articuloivanbascone, EntityManagerInterface $entityManager): Response
    {
        $form = $this->createForm(ArticuloivanbasconesType::class, $articuloivanbascone);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $entityManager->flush();

            return $this->redirectToRoute('app_articuloivanbascones_index', [], Response::HTTP_SEE_OTHER);
        }

        return $this->render('articuloivanbascones/edit.html.twig', [
            'articuloivanbascone' => $articuloivanbascone,
            'form' => $form,
        ]);
    }

    #[Route('/{id}', name: 'app_articuloivanbascones_delete', methods: ['POST'])]
    public function delete(Request $request, Articuloivanbascones $articuloivanbascone, EntityManagerInterface $entityManager): Response
    {
        if ($this->isCsrfTokenValid('delete'.$articuloivanbascone->getId(), $request->getPayload()->getString('_token'))) {
            $entityManager->remove($articuloivanbascone);
            $entityManager->flush();
        }

        return $this->redirectToRoute('app_articuloivanbascones_index', [], Response::HTTP_SEE_OTHER);
    }
}
