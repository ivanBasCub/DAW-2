<?php

namespace App\Form;

use App\Entity\Articuloivanbascones;
use App\Entity\Tipoivanbascones;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class ArticuloivanbasconesType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $builder
            ->add('titulo')
            ->add('fecha', null, [
                'widget' => 'single_text',
            ])
            ->add('texto')
            ->add('tipo', EntityType::class, [
                'class' => Tipoivanbascones::class,
                'choice_label' => 'tipo',
            ])
        ;
    }

    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults([
            'data_class' => Articuloivanbascones::class,
        ]);
    }
}
